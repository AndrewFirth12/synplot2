window = 25
c <- read.table("synplot_plot.txt")

library(caTools)

bitmap("plot.jpg",type="jpeg",height=0.04+0.8+0.45+0.15,width=0.02+nrow(c)/800+0.55,res=300,pointsize=14)

layout(matrix(c(1,1,1,2,3,4,2,5,6,7,7,7), 4, 3, byrow = TRUE), c(0.02,nrow(c)/800,0.55), c(0.04,0.8,0.45,0.15))

temp=c(0,1)
par(xaxs="i")
par(yaxs="i")
par(cex.axis=0.8)
par(mar=c(0,0,0,0))
par(tcl=-0.25)
par(mgp=c(0,0.5,0))
cc0 = 1.2
cc1 = 1.0
cc2 = 0.8

plot(temp,temp,type="n",xaxt="n",yaxt="n",ylab="",xlab="",axes=FALSE)
plot(temp,temp,type="n",xaxt="n",yaxt="n",ylab="",xlab="",axes=FALSE)

#------------------------------------------------------------------------------
#Plot p-values

par(yaxs="r")
nonzero_c = c[c$V4 != 0 ,]
threshold = 0.05/(nrow(c)/window)
plot(c(c$V1,1),c(pnorm(runmean(c$V2-c$V3,window)/sqrt(runmean(c$V4*c$V4,window))*sqrt(window)),threshold^2),type="n",ylab="",xlab="",xaxt="n",yaxt="n",log="y",xlim=c(0,nrow(c)),ylim=c(1,min(pnorm(runmean(c$V2-c$V3,window)/sqrt(runmean(c$V4*c$V4,window))*sqrt(window)),threshold^2)))
abline(h=threshold,lty="dashed",col="grey")
axis(side=4,las=2)
lines(c$V1,pnorm(runmean(c$V2-c$V3,window)/sqrt(runmean(c$V4*c$V4,window))*sqrt(window)),col="red")
par(yaxs="i")
plot(temp,temp,type="n",xaxt="n",yaxt="n",ylab="",xlab="",axes=FALSE)
text(0.9,0.5,labels="p-value",cex=cc1,adj=0.5,srt=270)

#------------------------------------------------------------------------------
#Plot obs/exp

plot(temp,temp,ylab="",xlab="",type="n",ylim=c(0,2),xlim=c(0,nrow(c)),yaxt="n",xaxt="n")
abline(h=1,lty="dashed")
axis(side=4,las=2,labels=c("0.0","0.5","1.0","1.5"),at=c(0.0,0.5,1.0,1.5))
lines(c$V1,runmean(c$V2,window)/runmean(c$V3,window),col="brown")
plot(temp,temp,type="n",xaxt="n",yaxt="n",ylab="",xlab="",axes=FALSE)
text(0.9,0.5,labels="obs/exp",cex=cc1,adj=0.5,srt=270)

#------------------------------------------------------------------------------

par(mar=c(0,0,0,0))
plot(temp,temp,type="n",xaxt="n",yaxt="n",ylab="",xlab="",axes=FALSE)

dev.off()
